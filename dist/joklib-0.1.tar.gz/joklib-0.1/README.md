This Library allows you with only a few lines of code to read out the klima data from J-O. Techniks Klimaboxen.
If you don`t have one of these or a simmillar system you wouldn`t probably use this library, because its main
function is to provide a simple accsess to them and also a few other things that good python programmers doesn`t
need, cause of their experience.

Copyright 2020 Jan-Ole G. (J-O. Technik)